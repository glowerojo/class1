
"""
TODO: add a docstring.

"""

class DoubleSection(object):

    def t(self):
        return True

    def two(self):
        return "second"
